import Navbar from "./components/Navbar";

import AboutMe from "./components/AboutMe";
import Skills from "./components/Skills";
import Projects from "./components/Projects";
import Footer from "./components/Footer";
import myImage from "./assets/myimg.png";






function App() {
  return (
    <>
      <Navbar />

    <AboutMe
    name="Muhammad Faizan"
     image={myImage}
    />


      <Skills
        skills={["HTML", "CSS", "JavaScript", "React"]}
      />

      <Projects />

      <Footer />
    </>
  );
}

export default App;
