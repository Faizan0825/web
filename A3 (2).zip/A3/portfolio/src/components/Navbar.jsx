function Navbar() {
  return (
    <nav className="navbar navbar-dark bg-dark">
      <div className="container">
        <a className="navbar text-white" href="portfolio">Portfolio</a>
        <a className="text-white" href="about">About</a>
        <a className="text-white" href="skills">Skills</a>
        <a className="text-white" href="project">Projects</a>
      </div>
    </nav>
  );
}

export default Navbar;
