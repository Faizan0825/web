function Skills({ skills }) {
  return (
    <div id="skills">
      <h2 className="text">Skills</h2>

      <div className="content center gap">
        {skills.map((skill, index) => (
          <span key={index} className="badge">
            {skill}
          </span>
        ))}
      </div>
    </div>
  );
}

export default Skills;
