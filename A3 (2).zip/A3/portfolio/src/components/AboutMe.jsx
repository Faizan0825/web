function AboutMe({ name, image }) {
  return (
    <div id="about" className="container t">
      <h2>About Me</h2>
     <img src={image} alt="Profile" />
 
      <h4>{name}</h4>

      <p>
        I am a Computer Science student learning web development.
        I enjoy building web applications using React and Bootstrap.
      </p>
    </div>
  );
}


export default AboutMe;
