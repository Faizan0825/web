function Footer() {
  return (
    <footer className="white text-center">
      © 2025 Muhammad Faizan
    </footer>
  );
}

export default Footer;
