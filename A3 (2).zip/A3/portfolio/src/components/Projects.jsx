import Button from "./Button";

function Projects() {
  return (
    <div id="projects">
      <h2 className="text-center">Projects</h2>

      <div className="row">
        <div className="col-md-6 mb-3">
          <div className="card">
            <h5>Portfolio Website</h5>
            <p>A personal portfolio built using React.</p>
            <Button
              text="View Project"
              onClick={() => alert("Project coming soon!")}
            />
          </div>
        </div>

        <div className="col">
          <div className="card">
            <h5>Todo App</h5>
            <p>A simple Todo application made with React.</p>
            <Button
              text="View Project"
              onClick={() => alert("Project coming soon!")}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default Projects;
