import { useEffect } from "react";

function Api() {
  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/users")
      .then(r => r.json())
      .then(d => console.log(d));
  }, []);

  return null;
}

export default Api;
