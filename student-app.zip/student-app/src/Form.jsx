import { useState, useContext } from "react";
import { Data } from "./Data";

function Form() {
  const { students, setStudents } = useContext(Data);

  const [name, setName] = useState("");
  const [roll, setRoll] = useState("");
  const [age, setAge] = useState("");
  const [dept, setDept] = useState("");

  function add(e) {
    e.preventDefault();
    setStudents([...students, { name, roll, age, dept }]);
    setName(""); setRoll(""); setAge(""); setDept("");
  }

  return (
    <form onSubmit={add}>
      <input placeholder="Name" value={name}
      
      onChange={e => setName(e.target.value)} />
      <input placeholder="Roll" value={roll}
      onChange={e => setRoll(e.target.value)} />

      <input placeholder="Age" value={age}
       onChange={e => setAge(e.target.value)} />

      <input placeholder="Department" value={dept} 
      onChange={e => setDept(e.target.value)} />
      <button type="submit">Add</button>
    </form>
  );
}

export default Form;
