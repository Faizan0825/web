import { createContext, useState } from "react";

export const Data = createContext();

export function DataProvider({ children }) {
  const [students, setStudents] = useState([]);

  return (
    <Data.Provider value={{ students, setStudents }}>
      {children}
    </Data.Provider>
  );
}

