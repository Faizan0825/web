import { useContext } from "react";
import { Data } from "./Data";

function List() {
  const { students } = useContext(Data);

  return (
    <ul>
      {students.map((s, i) => (
        <li key={i}>
          {s.name} | {s.roll} | {s.age} | {s.dept}
        </li>
      ))}
    </ul>
  );
}

export default List;
