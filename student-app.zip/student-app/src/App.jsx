import "./App.css";

import { DataProvider } from "./Data";
import Form from "./Form";
import List from "./List";
import Api from "./Api";

function App() {
  return (
    <DataProvider>
      <Form />
      <List />
    </DataProvider>
  );
}

export default App;
