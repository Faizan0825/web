import regImg from "../assets/reg-img.jpg";

function Registration() {
  return (
    <div className="registration-page">
      <h1>📝 Create Your Account</h1>
      <p>🛒 Join My Supermarket and enjoy exclusive benefits.</p>

      <div className="reg-container">
        <div className="reg-image">
          <img src={regImg} alt="Register" />
        </div>

        <form className="reg-form">
          <label>👤 Full Name</label>
          <input type="text" placeholder="Enter your full name" />

          <label>📧 Email Address</label>
          <input type="email" placeholder="Enter your email" />

          <label>📞 Phone Number</label>
          <input type="text" placeholder="Enter your phone number" />

          <label>🔒 Password</label>
          <input type="password" placeholder="Create a password" />

          <label>🔁 Confirm Password</label>
          <input type="password" placeholder="Confirm your password" />

          <button>✅ Create Account</button>
        </form>
      </div>
    </div>
  );
}

export default Registration;
