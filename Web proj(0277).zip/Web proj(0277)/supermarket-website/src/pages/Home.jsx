import fruitImg from "../assets/fruit-pic.jpeg";
import vegeImg from "../assets/vege-pic.jpg";
import dairyImg from "../assets/dairy-img.jpg";

function Home() {
  return (
    <div className="home-page">

      <div className="hero-card">
        <h1>Welcome to My Super Market!</h1>
        <p>Your One-Stop Shop for Fresh and Affordable Groceries</p>
      </div>

      
      <div className="info-box">
        <h3>Fresh Products, Great Prices!</h3>
        <p>
          <b>My Super Market</b> where quality meets affordability.
          We provide the freshest vegetables, fruits, dairy,
           and daily essentials.
        </p>
           <br></br>

        <p><b>Here's how you can start shopping with us:</b></p>
        <ol>
          <li>Register for free on our website.</li>
          <li>Browse our daily deals and discounts.</li>
          <li>Place your order and enjoy same-day delivery!</li>
        </ol>
      </div>

      <h2 className="section-title">Popular Categories</h2>
      <div className="categories">
        <div className="category-card">
          <img src={fruitImg} alt="Fruits" />
          <span><b>Fresh Fruits</b></span>
        </div>
        <div className="category-card">
          <img src={vegeImg} alt="Vegetables" />
          <span><b>Vegetables</b></span>
        </div>
        <div className="category-card">
          <img src={dairyImg} alt="Dairy" />
          <span><b>Dairy</b></span>
        </div>
      </div>

      <div className="features">
        <div className="feature">🥬 <h4>Fresh Produce</h4><p>Farm-fresh items daily</p></div>
        <div className="feature">💰 <h4>Best Prices</h4><p>Weekly special offers</p></div>
        <div className="feature">🚚 <h4>Home Delivery</h4><p>Free above 1000rs/-</p></div>
        <div className="feature">⭐ <h4>Quality Guaranteed</h4><p>100% satisfaction</p></div>
      </div>

      <div className="info-cards">
        <div className="card">
          <h3>Loyalty Points</h3>
          <ul>
            <li>10% off first purchase</li>
            <li>Weekly discounts</li>
            <li>Points on every 20000rs/-</li>
          </ul>
        </div>

        <div className="card">
          <h3>Featured Products</h3>
          <ul>
            <li>Organic fruits & vegetables</li>
            <li>Premium Basmati Rice</li>
            <li>Fresh Milk & Dahi</li>
            <li>Spices Collection</li>
          </ul>
        </div>
      </div>

      
      <div className="cta">
        <h2>Start Shopping Today!</h2>
        <p>Join thousands of happy customers who trust My Supermarket</p>
      </div>

    </div>
  );
}

export default Home;
