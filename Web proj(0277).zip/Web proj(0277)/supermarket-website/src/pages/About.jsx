import aboutImg from "../assets/about-img.avif";

function About() {
  return (
    <div className="about-page">

      <h1>About My Supermarket</h1>
      <p className="about-sub">
        Serving our community with fresh, quality products since 2010
      </p>

      <div className="about-card">

        <div className="about-top">
          <img src={aboutImg} alt="Supermarket" />

          <div className="about-text">
            <h2>Our Story</h2>
            <p>
              My Supermarket began as a small family-owned grocery store with a
              simple mission: to provide fresh products at fair prices. Over the
              years, we have grown into a trusted community supermarket.
            </p>
          </div>
        </div>

        <h2>Our Mission</h2>
        <p>
          To provide high-quality, fresh products at affordable prices while
          delivering excellent customer service.
        </p>

          <br></br>
        <h2>Our Values</h2>
        <div className="values">
          <div className="value-box">🌱 Freshness</div>
          <div className="value-box">🤝 Community</div>
          <div className="value-box">💚 Sustainability</div>
          <div className="value-box">😊 Service</div>
        </div>

        <h2>What We Offer</h2>
        <ul className="offer-list">
          <li>🍎 Fresh fruits and vegetables</li>
          <li>🥛 Dairy and grocery items</li>
          <li>🌾 Premium rice and grains</li>
          <li>🧂 Spices and daily essentials</li>
          <li>🚚 Home delivery service</li>
        </ul>

        <h2>Follow Us on Social Media</h2>
        <ul className="social">
          <li>📘 Facebook: facebook.com/MySuperMarket</li>
          <li>📸 Instagram: instagram.com/MySuperMarket</li>
          <li>🐦 Twitter: twitter.com/MySuperMarket</li>
          <li>▶️ YouTube: youtube.com/MySuperMarket</li>
        </ul>

      </div>

    </div>
  );
}

export default About;
