function Contact() {
  return (
    <div className="contact-page">
      <h1>📞 Contact Us</h1>
      <p>💬 Reach out to us through any of the following channels.</p>

      <div className="contact-boxes">
        <div className="contact-box">
          <h3>📍 Visit Our Store</h3>
          <p>Office No. 22</p>
          <p>Iqbal Avenue, Lahore</p>
          <p>Pakistan</p>
        </div>

        <div className="contact-box">
          <h3>📞 Call Us</h3>
          <p>+92 300 1000000</p>
          <p>Mon–Sat: 8am – 9pm</p>
        </div>

        <div className="contact-box">
          <h3>✉️ Email Us</h3>
          <p>info@mysupermarket.com</p>
        </div>

        <div className="contact-box">
          <h3>🕒 Store Hours</h3>
          <p>Mon–Fri: 7am – 10pm</p>
          <p>Sat: 8am – 9pm</p>
          <p>Sun: 9am – 8pm</p>
        </div>
      </div>

      <div className="contact-note">
        <h3>⚡ Need Immediate Assistance?</h3>
        <p>Our team is available during store hours to help you.</p>
      </div>
    </div>
  );
}

export default Contact;
