import { Link } from "react-router-dom";
import logo from "../assets/logo.jpg";

function Navbar() {
  return (
    <div className="navbar">
      <img src={logo} alt="My Supermarket" />
      <div>
        <Link to="/">🏠 Home</Link>
        <Link to="/registration">📝 Registration</Link>
        <Link to="/contact">📞 Contact</Link>
        <Link to="/about">ℹ️ About</Link>
      </div>
    </div>
  );
}

export default Navbar;
